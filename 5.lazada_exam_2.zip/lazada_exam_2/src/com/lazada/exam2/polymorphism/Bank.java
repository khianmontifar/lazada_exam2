package com.lazada.exam2.polymorphism;

public class Bank {
	float getRateOfInterest() {
		return 0;
	}
}
