package com.lazada.exam2.polymorphism;

public class BDO extends Bank {
	float getRateOfInterest() {
		return 7.3f;
	}
}
