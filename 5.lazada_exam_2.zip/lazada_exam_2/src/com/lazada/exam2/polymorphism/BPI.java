package com.lazada.exam2.polymorphism;

public class BPI extends Bank {
	float getRateOfInterest() {
		return 8.4f;
	}
}
