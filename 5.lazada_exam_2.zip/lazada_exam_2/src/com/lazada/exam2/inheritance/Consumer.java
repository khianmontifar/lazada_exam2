package com.lazada.exam2.inheritance;

public class Consumer extends AccountInfo {
	final String accountype = "Consumer";
}
