package com.lazada.exam2.inheritance;

public class Merchant extends AccountInfo {
	final String accountype = "Merchant";
}
