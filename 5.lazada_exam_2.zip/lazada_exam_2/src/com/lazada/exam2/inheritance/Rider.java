package com.lazada.exam2.inheritance;

public class Rider extends AccountInfo {
	final String accountype = "Rider";
}
